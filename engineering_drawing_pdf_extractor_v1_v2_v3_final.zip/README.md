# Engineering Drawing PDF Extractor (V1 + V2 + V3) — Offline / CPU-first

This repo is a **reusable, plugin-based extraction platform** for **engineering drawing PDFs**:
- CAD-export **vector PDFs** (text + vector paths)
- **scanned/raster PDFs** (OCR + CV)

It is architected like a *solution architect* would: **pipelines + stages + registries**, so you can add new features (symbols, BOM, title-block templates, DXF export, etc.) without rewriting core code.

---

## What you get (deliverables)

### V1 — Searchable + Structured
✅ Detect page type: VECTOR vs RASTER  
✅ Render pages (for raster)  
✅ Extract text blocks (vector PDFs) with coordinates  
✅ OCR (raster PDFs) with coordinates (PaddleOCR CPU; optional skip)  
✅ Export results as JSON per document  

### V2 — Dimensions (Structured)
✅ Parse dimension tokens: `Ø12`, `R20`, `45°`, `60.00`, `±0.1`, `+0.2/-0.0`  
✅ Produce normalized dimension objects with confidence  
✅ Works on both vector text + OCR text

### V3 — Geometry (Basic)
✅ VECTOR: extract drawing primitives from PDF paths (lines/rects/curves when available)  
✅ RASTER: detect candidate lines using OpenCV Hough  
✅ Baseline association between dimension text and nearby lines (heuristic)

---

## Architecture

**FastAPI** provides:
- upload PDF
- run extraction (sync or async via Celery)
- fetch results (JSON)

**Pipeline engine**:
- each stage reads/writes a shared `ExtractionContext`
- stages are **pluggable** (`StageRegistry`)
- choose pipeline: `v1`, `v2`, `v3`, or `final` (v1+v2+v3)

---

## Quickstart (Local)

### 1) Create venv and install
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

### 2) Run API
```bash
uvicorn app.main:app --reload --port 8000
```

Swagger:
- http://localhost:8000/docs

### 3) Use endpoints
1) Upload:
- `POST /api/v1/documents` (multipart file)

2) Run:
- `POST /api/v1/documents/{doc_id}/run?pipeline=final`

3) Download result:
- `GET /api/v1/documents/{doc_id}/result`

---

## Docker (recommended)

### 1) Start
```bash
docker compose up -d --build
```

### 2) Async run (Celery)
- `POST /api/v1/documents/{doc_id}/run_async?pipeline=final`

---

## Configuration

Env vars (optional):
- `DATABASE_URL` (default: sqlite `data/app.db`)
- `REDIS_URL`
- `STORAGE_DIR` (default: `data/storage`)
- `OCR_ENGINE` (`paddle` or `none`) default: `paddle`
- `RENDER_DPI` default: `300`
- `PIPELINE_DEFAULT` default: `final`

---

## Add new functionality

1) Add a stage in:
`app/services/pipeline/stages/`

2) Register:
- import in `app/services/pipeline/stages/__init__.py`
- add stage name to a pipeline in `app/services/pipeline/pipelines.py`

---

## Output JSON (what manager expects)
- per-page:
  - `page_type`
  - `vector_text` + `ocr_text` (with bboxes)
  - `dimensions` (V2)
  - `geometry` (V3)

---

## Notes
- PaddleOCR is heavy; if install fails, set `OCR_ENGINE=none`.
- Increase DPI to 400–600 for small text.
