import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings

Base = declarative_base()
_engine = None
SessionLocal = None

def get_engine():
    global _engine
    if _engine is None:
        os.makedirs("data", exist_ok=True)
        _engine = create_engine(settings.database_url, future=True)
    return _engine

def init_db():
    global SessionLocal
    engine = get_engine()
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    from app.db import models  # noqa
    Base.metadata.create_all(bind=engine)
